let menuclass = document.querySelector('.mobilemenu');
let main = document.querySelector('.main-menu');

menuclass.addEventListener('click',()=>{
    main.classList.toggle('show');
})


